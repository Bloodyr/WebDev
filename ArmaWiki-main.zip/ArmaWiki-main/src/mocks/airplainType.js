export default [
    [ 
        {
            id: 0,
            src: 'https://pbs.twimg.com/media/Egh0I5yUcAAaL73.jpg', 
            name:'Фронтовая'
        },
        {
            id: 1,
            src:'https://novosti-saratova.ru/wp-content/uploads/2019/12/29946918.jpg', 
            name:'Дальняя'
        }
    ],
    [
        {
            id: 0,
            src:'https://www.sila-rf.ru/wp-content/uploads/2021/02/f1eb3064d4b1f25eba2570981c15e9f9.jpe', 
            name:'Штурмовики'
        },
        {
            id: 1,
            src:'https://gunsfriend.ru/wp-content/uploads/7/f/9/7f9e3171258fd6fe59433f6c3a740e94.jpg', 
            name:'Бомбардировщики'
        },
        {
            id: 2,
            src:'https://i.pinimg.com/originals/84/f1/99/84f1998fe2fba3729cdb9795c271b03a.jpg', 
            name:'Истребители'
        },
        {
            id: 3,
            src:'https://rostec.ru/upload/iblock/450/450b762ce619452f291d79e6f2f01ce1.jpg', 
            name:'Вертолеты'
        },
    ]
]