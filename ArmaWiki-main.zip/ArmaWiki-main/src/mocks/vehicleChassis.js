export default [
    ['https://upload.wikimedia.org/wikipedia/commons/thumb/7/79/Special_wheeled_chassis_BAZ-M6910E_in_2010.jpg/1200px-Special_wheeled_chassis_BAZ-M6910E_in_2010.jpg', 'Колесное шасси'],
    ['https://avatars.mds.yandex.net/get-zen_doc/3985268/pub_5f4cff78687ed21d30b549b8_5f4d007f119e705454bf31ae/scale_1200', 'Гусеничное шасси'],
]