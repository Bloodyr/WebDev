export default [
    ['https://www.ab-aviationreporter.com/wp-content/uploads/2019/07/1024px-Great_emblem_of_the_Russian_Air-Cosmic_Forces.svg_.jpg', 'Воздушно-Космические силы(ВКС)', 'ВКС'],
    ['https://specialoil.ru/images/virtuemart/product/Rt001001783_1.jpg', 'Военно-Морской флот(ВМФ)', 'ВМФ'],
    ['https://ataka-torg.ru/images/companies/1/blog-photo/%D0%B2%D0%B4%D0%B2%20%D0%BB%D0%BE%D0%B3%D0%BE.jpg?1564571941914', 'Воздушно-Десантные войска(ВДВ)', 'ВДВ'],
    ['https://topwar.ru/uploads/posts/2017-08/1501849493_5ohyfewx3me.jpg', 'Танковые войска', 'ТВ']
]