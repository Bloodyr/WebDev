export default [
    ['https://ic.pics.livejournal.com/bmpd/38024980/631975/631975_original.jpg', 'Авиация'],
    ['https://i.ytimg.com/vi/tDooObgq-is/maxresdefault.jpg', 'Наземный вид техники'],
    ['https://img-fotki.yandex.ru/get/5626/137106206.336/0_c2676_87baed7d_orig.jpg', 'Водная техника']
]